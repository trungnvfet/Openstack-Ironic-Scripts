#include <ipxe/nap.h>

PROVIDE_NAP_INLINE ( null, cpu_nap );
