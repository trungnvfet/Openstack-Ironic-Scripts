#ifndef _BITS_NAP_H
#define _BITS_NAP_H

/** @file
 *
 * ARM-specific CPU sleeping API implementations
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

#include <ipxe/efi/efiarm_nap.h>

#endif /* _BITS_MAP_H */
